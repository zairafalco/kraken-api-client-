### Versions

```
OS:       
Python:   
krakenex: 
```

### What are you trying to achieve?



``` python
# code sample

```

### What do you expect to happen?



### What happens instead?



``` python
# error message

```
