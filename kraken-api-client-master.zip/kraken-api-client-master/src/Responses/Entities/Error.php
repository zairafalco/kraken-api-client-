<?php
declare(strict_types=1);

namespace Butschster\Kraken\Responses\Entities;

class Error
{

}