<?php
declare(strict_types=1);

namespace Butschster\Kraken\Contracts;

interface WebsocketEvent
{
}