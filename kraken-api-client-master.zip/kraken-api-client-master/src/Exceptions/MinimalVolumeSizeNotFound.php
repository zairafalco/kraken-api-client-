<?php

namespace Butschster\Kraken\Exceptions;

class MinimalVolumeSizeNotFound extends \Exception
{

}